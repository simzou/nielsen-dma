class MarketProcessor {

  constructor(dma_objects) {
    this.dma_objects = dma_objects;
    this.total_population = this.count_population(this.dma_objects.fills[0]);
  }


  process() {
    // var fill_0 = this.dma_objects.fills[0];
    // console.log(typeof fill_0);
    // console.log(fill_0.constructor.name);
    // console.log(fill_0.__data__);

    // var event = document.createEvent('Event');
    // // Define that the event name is 'build'.
    // event.initEvent('highlight', true, true);

    //fill_0.dispatchEvent(event);

    //console.log(this.count_population(this.dma_objects.fills));

    var parts = this.divide_into(10, this.dma_objects.fills[0]);

    this.color_parts(this.final_parts);

    // var parts = this.divide_along_longitude(this.dma_objects.fills[0]);
    // window.parts = parts[0];
    console.log(this.final_parts);
    for (var i in parts[0]) {
      //d3.select(parts[0][i]).attr('fill', 'red');
    }
    
  }

  divide_into(count, fills) {
    var target_population = Math.ceil(this.total_population / count);
    this.final_parts = [];
    return this.divide_to(target_population, fills);
  }

  // recursive function
  divide_to(target_population, fills, iteration) {
    if (iteration == null) { iteration = 1; }

    var direction = ['longitude', 'latitude'][iteration % 2];

    console.log('iteration', iteration, 'dividing along', direction);

    var output_parts = []

    var parts = this.divide_along(direction, fills);

    // TODO: fix this; shouldn't need to break after set number of iterations
    //if (iteration > 20) return parts;
    for (var i = 0; i < parts.length; i++) {
      var current_population = this.count_population(parts[i]);
      console.log('population', current_population, 'length', parts[i].length);
      // if (current_population == 12480660) {
      //   for (var j = 0; j < parts[i].length; j++) {
      //     console.log(parseInt(parts[i][j].__data__.properties['TV Homes'], 10));
      //   }
      // }
      if (parts[i].length > 1 && current_population > target_population) {
        parts[i] = this.divide_to(target_population, parts[i], iteration + 1);
      }
      else {
        this.final_parts.push(parts[i]);
      }
    }
    return parts;
  }

  //  ------------
  // |     |      |
  // |     |      |
  //  ------------

  divide_along(property, fills) {
    var fills_sorted = fills.sort(function (fill_a, fill_b) {
      if (fill_a.__data__.properties[property] < fill_b.__data__.properties[property]) {
        return -1;
      }
      return 1;
    });
    return this.divide_in_half(fills_sorted);
  }

  // convenience function
  divide_along_longitude(fills) {
    return this.divide_along('longitude', fills);
  }

  // convenience function
  divide_along_latitude(fills) {
    return this.divide_along('latitude', fills);
  }

  divide_in_half(fills) {
    var parts = [[], []];
    var target_population = Math.ceil(this.count_population(fills) / 2);
    var running_population = 0;
    var i;
    for (i = 0; i < fills.length; i++) {
      var tv_homes = parseInt(fills[i].__data__.properties['TV Homes'], 10);
      // TODO: improve this to choose closer to half
      // ... something like comparing Math.abs(running_population + tv_homes - target_population) and Math.abs(target_population - running_population) 
      parts[0].push(fills[i]);
      running_population += tv_homes;
      if (running_population >= target_population) {
        break;
      }
    }
    parts[1] = fills.slice(i + 1, fills.length);
    return parts;
  }

  count_population(fills) {
    var running_population = 0;
    for (var i = 0; i < fills.length; i++) {
      var tv_homes = parseInt(fills[i].__data__.properties['TV Homes'], 10);
      running_population += tv_homes;
    }
    return running_population;
  }

  color_parts(parts) {
    var parts_count = parts.length;
    var hsl_increment = Math.floor(360 / parts_count); // 0-360
    var s = '50%'; // 0-100
    var l = '50%'; // 0-100
    for (var i = 0; i < parts_count; i++) {
      var h = hsl_increment * (i + 1);
      var color = d3.hsl(h, s, l);
      console.log(color);
      for (var j = 0; j < parts[i].length; j++) {
        var d = d3.select(parts[i][j]);
        d.attr('fill', 'hsl(' + h + ', ' + s + ', ' + l + ')');
        //d3.select(parts[i][j]).dispatch('highlight');
        console.log(d.attr('fill'));
      }
    }
  }

}
